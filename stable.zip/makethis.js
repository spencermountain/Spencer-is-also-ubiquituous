
CmdUtils.CreateCommand( {
	names: [ "make this","add to freebase"],
	arguments: [  ],
        description: "creates a topic for the current website",
        icon: "http://www.freebase.com/favicon.ico",
        homepage: "http://spencerwaterbed.com/soft/ubiquity/makethis.html",
        author: { name: "Spencer Kelly", email: "spencerwater@gmail.com"},
        license: "GPL",


	execute: function( args ){
		

		Utils.openUrlInBrowser( 'http://george.freebaseapps.com/boyfriend?url='+url);
		return true;
	},
 

 	 preview: function(pblock, args ) {
		url = context.focusedWindow.document.location + ""; 


  		  pblock.innerHTML = _("looking...") ;

  		    		   pblock.innerHTML = '<iframe width="99%" height="99%" border="0" src="http://george.freebaseapps.com/boyfriend?url='+url+'"/>';

  },
});  
